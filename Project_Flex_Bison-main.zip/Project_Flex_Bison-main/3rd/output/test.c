#include <stdio.h>

int main() {
    
    int a = 10;

    int a = 'a';

    printf("%d %c", a, a);

    return 0;
}